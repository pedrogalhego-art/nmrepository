let state={user:null,products:[],categories:[]};
const $=s=>document.querySelector(s);
async function api(url,opts={}){const r=await fetch(url,{headers:{"Content-Type":"application/json"},...opts});let d={};try{d=await r.json()}catch{}if(!r.ok)throw new Error(d.error||"Erro");return d}
async function init(){
  const me=await api("/api/me"); if(!me.user){$("#login").classList.remove("hidden");$("#app").classList.add("hidden");return}
  state.user=me.user;$("#login").classList.add("hidden");$("#app").classList.remove("hidden");
  $("#userName").textContent=state.user.username;$("#roleBadge").textContent=state.user.role==="admin"?"ADMINISTRADOR":"PROJETO";
  $("#permission").textContent=state.user.role==="admin"?"Você pode abastecer e dar baixa":"Acesso somente para consulta";
  await refresh(); buildTicker();
}
async function refresh(){state.products=await api("/api/products");renderProducts();renderStats();renderCategories();renderMovements()}
function renderCategories(){let c=[...new Set(state.products.map(p=>p.category))].sort();let sel=$("#category"),old=sel.value;sel.innerHTML='<option value="">Todas as categorias</option>'+c.map(x=>`<option>${x}</option>`).join("");sel.value=old}
function filtered(){let q=$("#search").value.toLowerCase(),c=$("#category").value;return state.products.filter(p=>(!c||p.category===c)&&(!q||p.code.toLowerCase().includes(q)||p.name.toLowerCase().includes(q)))}
function renderProducts(){
 let rows=filtered(); $("#products").innerHTML=rows.map(p=>{let total=(p.stock*(p.weight_6m||0)).toFixed(2).replace(".",",");
 let actions=state.user.role==="admin"?`<div class="action"><button class="in" onclick="openMove(${p.id},'abastecimento')">+ Abastecer</button><button class="out" onclick="openMove(${p.id},'baixa')">− Baixar</button></div>`:`<span class="mini">Somente leitura</span>`;
 return `<tr><td><span class="cat-badge">${esc(p.category)}</span></td><td>${esc(p.code)}</td><td>${esc(p.name)}</td><td>${p.weight_6m?p.weight_6m.toFixed(2).replace(".",",")+" kg":"—"}</td><td class="stock ${p.stock===0?"zero":""}">${p.stock}</td><td>${total} kg</td><td>${actions}</td></tr>`}).join("")||`<tr><td colspan="7" class="muted">Nenhum material encontrado.</td></tr>`;
}
function renderStats(){let total=state.products.reduce((a,p)=>a+p.stock,0),kg=state.products.reduce((a,p)=>a+p.stock*(p.weight_6m||0),0),cats=new Set(state.products.map(p=>p.category)).size,zero=state.products.filter(p=>p.stock===0).length;
$("#stats").innerHTML=[["Barras em estoque",total],["Peso estimado",kg.toLocaleString("pt-BR",{maximumFractionDigits:2})+" kg"],["Categorias",cats],["Itens zerados",zero]].map(x=>`<div class="stat"><small>${x[0]}</small><strong>${x[1]}</strong></div>`).join("")}
async function renderMovements(){let m=await api("/api/movements");$("#movements").innerHTML=m.map(x=>`<div class="movement"><div class="line"><strong>${esc(x.code)} · ${esc(x.name)}</strong><span class="qty ${x.type==="abastecimento"?"in":"out"}">${x.type==="abastecimento"?"+":"−"}${x.quantity}</span></div><small>${esc(x.category)} · ${esc(x.username)} · ${new Date(x.created_at.replace(" ","T")+"Z").toLocaleString("pt-BR")}${x.note?" · "+esc(x.note):""}</small></div>`).join("")||`<div class="movement muted">Nenhuma movimentação ainda.</div>`}
function buildTicker(){let cats=[...new Set(state.products.map(p=>p.category))];$("#ticker").innerHTML='<div class="ticker-track">'+cats.concat(cats).map(c=>{let items=state.products.filter(p=>p.category===c);let n=items.reduce((a,p)=>a+p.stock,0);return `<span class="tick"><b>${esc(c)}</b> ${n} barras</span>`}).join("")+"</div>"}
function openMove(id,type){let p=state.products.find(x=>x.id===id);$("#modal").classList.remove("hidden");$("#productId").value=id;$("#moveType").value=type;$("#modalType").textContent=type==="abastecimento"?"ABASTECIMENTO":"BAIXA";$("#modalTitle").textContent=p.name;$("#modalInfo").textContent=`${p.code} · Estoque atual: ${p.stock} barra(s)`;$("#moveBtn").textContent=type==="abastecimento"?"Confirmar abastecimento":"Confirmar baixa";$("#moveError").textContent="";$("#quantity").value="";$("#note").value="";$("#quantity").focus()}
$("#close").onclick=()=>$("#modal").classList.add("hidden");$("#modal").onclick=e=>{if(e.target.id==="modal")$("#modal").classList.add("hidden")};
$("#moveForm").onsubmit=async e=>{e.preventDefault();try{await api("/api/movement",{method:"POST",body:JSON.stringify({productId:Number($("#productId").value),type:$("#moveType").value,quantity:Number($("#quantity").value),note:$("#note").value})});$("#modal").classList.add("hidden");await refresh();buildTicker()}catch(err){$("#moveError").textContent=err.message}};
$("#loginForm").onsubmit=async e=>{e.preventDefault();$("#loginError").textContent="";try{await api("/api/login",{method:"POST",body:JSON.stringify({username:$("#username").value,password:$("#password").value})});await init()}catch(err){$("#loginError").textContent=err.message}};
$("#logout").onclick=async()=>{await api("/api/logout",{method:"POST"});location.reload()};
$("#search").oninput=renderProducts;$("#category").onchange=renderProducts;
const socket=io();socket.on("inventory:update",async()=>{if(state.user){await refresh();buildTicker()}});
function esc(s){return String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
init();