require("dotenv").config();
const express=require("express");
const http=require("http");
const path=require("path");
const session=require("express-session");
const bcrypt=require("bcryptjs");
const Database=require("better-sqlite3");
const {Server}=require("socket.io");
const fs=require("fs");

const app=express();
const server=http.createServer(app);
const io=new Server(server);
const db=new Database(process.env.DB_FILE||"estoque.db");
db.pragma("journal_mode=WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS users(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 username TEXT UNIQUE NOT NULL,
 password_hash TEXT NOT NULL,
 role TEXT NOT NULL CHECK(role IN ('admin','projeto')),
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS products(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 category TEXT NOT NULL,
 code TEXT NOT NULL,
 name TEXT NOT NULL,
 weight_6m REAL,
 stock INTEGER NOT NULL DEFAULT 0,
 UNIQUE(category,code)
);
CREATE TABLE IF NOT EXISTS movements(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 product_id INTEGER NOT NULL,
 user_id INTEGER NOT NULL,
 type TEXT NOT NULL CHECK(type IN ('abastecimento','baixa')),
 quantity INTEGER NOT NULL,
 note TEXT,
 created_at TEXT DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(product_id) REFERENCES products(id),
 FOREIGN KEY(user_id) REFERENCES users(id)
);
`);

const products=JSON.parse(fs.readFileSync(path.join(__dirname,"products.json"),"utf8"));
const insertProduct=db.prepare(`INSERT OR IGNORE INTO products(category,code,name,weight_6m) VALUES(?,?,?,?)`);
const seedProducts=db.transaction(()=>Object.entries(products).forEach(([cat,items])=>items.forEach(p=>insertProduct.run(cat,p.code,p.name,p.weight_6m))));
seedProducts();

const countUsers=db.prepare("SELECT COUNT(*) c FROM users").get().c;
if(!countUsers){
  const ins=db.prepare("INSERT INTO users(username,password_hash,role) VALUES(?,?,?)");
  ins.run("admin",bcrypt.hashSync(process.env.ADMIN_PASSWORD||"admin123",12),"admin");
  ins.run("projeto",bcrypt.hashSync(process.env.PROJETO_PASSWORD||"projeto123",12),"projeto");
}

app.use(express.json());
app.use(express.urlencoded({extended:true}));
app.use(session({
 secret:process.env.SESSION_SECRET||"troque-esta-chave",
 resave:false,saveUninitialized:false,
 cookie:{httpOnly:true,sameSite:"lax",secure:process.env.NODE_ENV==="production",maxAge:8*60*60*1000}
}));
app.use(express.static(path.join(__dirname,"public")));

function auth(req,res,next){ if(!req.session.user) return res.status(401).json({error:"Não autenticado"}); next(); }
function admin(req,res,next){ if(!req.session.user || req.session.user.role!=="admin") return res.status(403).json({error:"Acesso permitido somente ao administrador"}); next(); }

app.get("/api/me",(req,res)=>res.json({user:req.session.user||null}));
app.post("/api/login",(req,res)=>{
 const {username,password}=req.body;
 const u=db.prepare("SELECT * FROM users WHERE username=?").get(String(username||"").trim());
 if(!u || !bcrypt.compareSync(String(password||""),u.password_hash)) return res.status(401).json({error:"Usuário ou senha inválidos"});
 req.session.user={id:u.id,username:u.username,role:u.role};
 res.json({user:req.session.user});
});
app.post("/api/logout",(req,res)=>req.session.destroy(()=>res.json({ok:true})));

app.get("/api/categories",auth,(req,res)=>{
 const rows=db.prepare(`SELECT category,COUNT(*) items,SUM(stock) pieces,SUM(stock*COALESCE(weight_6m,0)) kg
 FROM products GROUP BY category ORDER BY category`).all();
 res.json(rows);
});
app.get("/api/products",auth,(req,res)=>{
 const q=String(req.query.q||"").trim(), cat=String(req.query.category||"").trim();
 let sql=`SELECT * FROM products WHERE 1=1`, params=[];
 if(cat){sql+=" AND category=?";params.push(cat)}
 if(q){sql+=" AND (code LIKE ? OR name LIKE ?)";params.push("%"+q+"%","%"+q+"%")}
 sql+=" ORDER BY category,name";
 res.json(db.prepare(sql).all(...params));
});
app.get("/api/movements",auth,(req,res)=>{
 const rows=db.prepare(`SELECT m.id,m.type,m.quantity,m.note,m.created_at,p.category,p.code,p.name,u.username
 FROM movements m JOIN products p ON p.id=m.product_id JOIN users u ON u.id=m.user_id
 ORDER BY m.id DESC LIMIT 100`).all();
 res.json(rows);
});
app.post("/api/movement",admin,(req,res)=>{
 const {productId,type,quantity,note}=req.body;
 const qty=Math.floor(Number(quantity));
 if(!Number.isInteger(Number(productId)) || !["abastecimento","baixa"].includes(type) || qty<=0) return res.status(400).json({error:"Dados inválidos"});
 const tx=db.transaction(()=>{
   const p=db.prepare("SELECT * FROM products WHERE id=?").get(productId);
   if(!p) throw new Error("Material não encontrado");
   if(type==="baixa" && p.stock<qty) throw new Error(`Estoque insuficiente. Disponível: ${p.stock} peça(s).`);
   const delta=type==="abastecimento"?qty:-qty;
   db.prepare("UPDATE products SET stock=stock+? WHERE id=?").run(delta,productId);
   db.prepare("INSERT INTO movements(product_id,user_id,type,quantity,note) VALUES(?,?,?,?,?)").run(productId,req.session.user.id,type,qty,String(note||"").slice(0,250));
 });
 try{tx(); const payload={...req.body,user:req.session.user.username}; io.emit("inventory:update",payload); res.json({ok:true});}
 catch(e){res.status(400).json({error:e.message});}
});

app.post("/api/users/password",auth,(req,res)=>{
 const {currentPassword,newPassword}=req.body;
 if(!newPassword || String(newPassword).length<8) return res.status(400).json({error:"A nova senha deve ter pelo menos 8 caracteres."});
 const u=db.prepare("SELECT * FROM users WHERE id=?").get(req.session.user.id);
 if(!bcrypt.compareSync(String(currentPassword||""),u.password_hash)) return res.status(400).json({error:"Senha atual incorreta."});
 db.prepare("UPDATE users SET password_hash=? WHERE id=?").run(bcrypt.hashSync(newPassword,12),u.id);
 res.json({ok:true});
});

app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
io.on("connection",socket=>{});

const PORT=process.env.PORT||3000;
server.listen(PORT,()=>console.log(`Estoque rodando em http://localhost:${PORT}`));
